const config = {
    SALT_ROUND : 10 ,
    secret : 'djfkjdfkdfkjsdfdfksdf'
}

module.exports = config